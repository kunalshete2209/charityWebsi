# Payment-Gateway-Integration
payment-gateway integration is the task given by spark foundation as a part of internship june 21.
This is Simple Charity Website where payment gateway is integrated. There is simple donate button on homepage  created via Razorpay.
On clicking  the donate button, user will land on payment page where user can select the amount to be paid and the available payment type.
Once the payment is done invoice will be generated and email will be sent to the user for payment recived.
